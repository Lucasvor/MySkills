# Handoff de implementação — Toolbar de filtros «Opção 1 — Equilibrada»

> **Status:** especificação visual e funcional pronta para implementação.  
> **Base visual:** imagem fornecida pelo solicitante (`referencia-opcao-1-equilibrada.png`).  
> **Idioma:** português do Brasil. **Tema de referência:** escuro (dark).  
> **Escopo:** **somente o componente de pesquisa, filtros e ações** da tela de Câmbio; não redesenhar cards, tabela, paginação ou outras telas.

![Referência visual — Opção 1 Equilibrada](./referencia-opcao-1-equilibrada.png)

## 1. Instruções diretas ao agente

Implementar fielmente a toolbar acima, de modo **responsivo, acessível e integrado aos filtros e comandos já existentes** no projeto. Primeiro inspecionar os componentes, estilos, rotas, stores/estados, serviços e contratos atuais. **Reaproveitar as funções de negócio, opções dos selects, permissões, endpoints, componente de calendário e comportamento da tabela presentes no repositório.** Não inventar valores, rotas, endpoints, novas permissões ou novos tipos de operação.

**Esta especificação diferencia:**

- **[REFERÊNCIA]** — elemento ou aspecto diretamente visível na imagem.
- **[RECOMENDAÇÃO]** — comportamento, tamanho ou regra sugerida para tornar a implementação completa; ajustar às convenções existentes sem mudar a proposta visual.
- **[VALIDAR]** — aspecto que a imagem não comprova e que deve ser obtido do código atual ou confirmado com o responsável.

**Não usar a imagem como plano de fundo nem recriar a toolbar com CSS de posições absolutas.** O resultado deve ser composto por controles HTML/semânticos reais, com estado e interação.

## 2. Objetivo de UX

A proposta divide claramente o trabalho em **duas faixas horizontais**:

1. **Linha superior — localizar e agir:** pesquisa flexível à esquerda; `CSV`, `Atualizar` e `Novo` à direita.
2. **Linha inferior — restringir resultados:** `Período de criação`, `Todos os tipos`, `Situação`, `Mesa` e o comando secundário `Limpar filtros` à direita.

As duas faixas são separadas por um divisor horizontal discreto. O usuário deve identificar imediatamente o campo de busca, conseguir combinar filtros e encontrar as ações principais sem competir visualmente com elas.

### 2.1 Hierarquia de destaque

1. **Novo:** botão principal (fundo branco e texto escuro na referência escura).
2. **Busca:** maior área interativa; fundo sutilmente destacado.
3. **Filtros:** botões contornados de destaque médio; valores escolhidos aparecem no próprio controle.
4. **CSV e Atualizar:** ações secundárias contornadas.
5. **Limpar filtros:** ação textual discreta, sem contorno, desabilitada quando não houver filtro ativo.

**Importante:** o botão `Atualizar` (refresh) é obrigatório; **não** confundi-lo com `Limpar filtros`.

## 3. Anatomia exata do componente

```text
┌──────────────────────────────────────────────────────────────────────────────────┐
│                                                                                  │
│  [ 🔍 Buscar por ID, cliente ou operação...                ] [ ⇩ CSV ] [ ↻ ] [ ＋ Novo ] │
│                                                                                  │
│  ───────────────────────────── divisor ─────────────────────────────────────────  │
│                                                                                  │
│  [ ▦ Período de criação ˅ ] [ Todos os tipos ˅ ] [ Situação ˅ ] [ Mesa ˅ ]     × Limpar filtros │
│                                                                                  │
└──────────────────────────────────────────────────────────────────────────────────┘
```

O desenho acima é conceitual; **a imagem é a fonte principal para os espaçamentos visuais**. Na imagem original, com **729 × 165 pixels**, o contêiner tem bordas arredondadas e fundo quase preto; a busca ocupa a maior parte da primeira linha; os botões de ação têm alinhamento central; e `Limpar filtros` fica no extremo direito da segunda linha.

## 4. Layout e medidas

As medidas a seguir são **[RECOMENDAÇÃO]**, inferidas visualmente; não são dimensões fixas impostas pelo arquivo de imagem.

| Parte | Especificação sugerida | Observações |
|---|---|---|
| Card externo | largura `100%`, borda `1px`, raio `12–14px` | manter o estilo atual do sistema |
| Padding do card | `12–14px` horizontal; `12–16px` vertical | screenshot usa margens internas compactas |
| Linha 1 | `display:flex; align-items:center; gap:8px` | sem alturas artificiais |
| Pesquisa | `flex:1 1 auto; min-width:240px; height:48px` | ocupa toda a largura remanescente |
| Botão CSV | altura `32–36px`, largura determinada pelo texto e ícone | ícone download + `CSV` |
| Botão Atualizar | quadrado `32–36px` | somente ícone, tooltip e nome acessível |
| Botão Novo | altura `32–36px`, largura pelo conteúdo | ícone plus + `Novo` |
| Divisor | `height:1px; width:100%;` | entre as linhas, com margens verticais de ~18–20px |
| Linha 2 | `display:flex; align-items:center; gap:8px` | `Limpar filtros` empurrado à direita |
| Filtro Período | altura `40px`; largura desejada `174px` | ícone à esquerda e chevron à direita |
| Filtro Tipo | altura `40px`; largura desejada `130px` | label `Todos os tipos` inicialmente |
| Filtro Situação | altura `40px`; largura desejada `95px` | mostrar seleção atual quando houver |
| Filtro Mesa | altura `40px`; largura desejada `76px` | evitar truncamento do valor selecionado |
| Limpar filtros | sem fundo; sem borda; `margin-left:auto` | texto + `×` discreto |
| Espaçamento entre controles | `8px` | não comprimir fonte para caber |
| Tipografia | `12–13px` nos controles; peso médio | respeitar tipografia global do app |
| Ícones | `14–16px`, traço fino | usar biblioteca de ícones existente |

**Ajuste prioritário:** manter o campo de busca elástico e os comandos agrupados à direita; a segunda linha **não** deve distribuir filtros com `justify-content: space-between` em toda a largura (isso criaria vãos excessivos). Use um grupo alinhado à esquerda e o `Limpar filtros` no extremo direito.

## 5. Paleta e estados visuais — tema escuro

A tela de referência é dark. Valores a seguir são **tokens aproximados**, sujeitos à substituição por tokens já existentes no projeto:

```css
/* Tokens sugeridos, não uma exigência para sobrescrever o design system */
--toolbar-bg:            #181818;
--toolbar-border:        #2c2c2c;
--toolbar-search-bg:     #141414;
--toolbar-control-bg:    #191919;
--toolbar-control-border:#303030;
--toolbar-text:          #f1f1f1;
--toolbar-muted:         #b2b2b2;
--toolbar-placeholder:   #aaa8a8;
--toolbar-primary-bg:    #f5f5f5;
--toolbar-primary-text:  #222222;
--toolbar-hover:         #242424;
--toolbar-focus-ring:    #8db4ff;
--toolbar-divider:       #252525;
```

### 5.1 Visual de interação

| Estado | Comportamento visual recomendado |
|---|---|
| Normal | borda discreta, fundo escuro, tipografia clara |
| Hover | borda/fundo levemente mais claros; sem alterar o layout |
| Focus via teclado | anel visível externo (`:focus-visible`), contrastante |
| Ativo / aberto | borda realçada e chevron podendo rotacionar |
| Com filtro selecionado | rótulo substituído pelo valor, contraste reforçado opcional |
| Desabilitado | opacidade reduzida e ausência de ação |
| Loading | spinner **no refresh**; impedir múltiplos disparos |
| Erro | feedback acessível e recuperável; não descartar filtros |

Não usar cores exclusivamente para indicar seleção/erro; garantir contraste adequado em temas disponíveis.

## 6. Detalhamento funcional campo a campo

### F01 — Pesquisa global

- **[REFERÊNCIA]** Primeiro elemento da primeira linha, à esquerda; ícone de lupa; placeholder **`Buscar por ID, cliente ou operação...`**.
- **[RECOMENDAÇÃO]** `input[type="search"]` real; aceitar termos alfanuméricos; controlar pelo estado atual de pesquisa; ícone não clicável/decorativo; botão nativo/visível de limpar o valor se a UI existente permitir.
- **Ao digitar:** atualizar a pesquisa usando o mecanismo atual; se houver consultas de rede a cada alteração, aplicar debounce de ~`300ms`. `Enter` pode executar imediatamente; apagar deve reaplicar a busca vazia. Evitar requisições com termos idênticos.
- **Integração:** respeitar exatamente quais colunas hoje participam da pesquisa (ID, cliente, operação são sugeridas pelo placeholder, mas **[VALIDAR]** no código).
- **Com filtros combinados:** realizar interseção entre texto, período, tipo, situação e mesa, conforme lógica atual do backend/frontend.
- **Acessibilidade:** `aria-label="Buscar operações por ID, cliente ou operação"`; suporte a teclado; não usar apenas placeholder se já houver padrão de labels acessíveis.

### F02 — Botão `CSV`

- **[REFERÊNCIA]** Primeiro botão do grupo de ações à direita; contorno arredondado; ícone de download e texto curto **`CSV`** (não `Exportar CSV`, para permanecer fiel à imagem atual).
- **Ação:** acionar **a exportação CSV já existente**.
- **[VALIDAR]** Escopo do export: página atual, seleção ou todos os registros filtrados; preservar a regra de negócio preexistente. Se o comportamento não estiver implementado, perguntar antes de escolher.
- **Estados:** habilitado/desabilitado conforme permissão e dados; indicar processamento enquanto o arquivo é preparado; evitar cliques duplicados; apresentar erro se a exportação falhar.
- **Acessibilidade:** nome `Exportar CSV`, ainda que visualmente apareça só `CSV`.

### F03 — Botão `Atualizar` (refresh)

- **[REFERÊNCIA]** Botão quadrado arredondado apenas com ícone de seta circular, **entre `CSV` e `Novo`**.
- **Ação:** refazer a consulta dos resultados com **a pesquisa, filtros, ordenação e paginação atuais**, preservando-os; usar fluxo de invalidação/revalidação/cache do app se houver.
- **Não deve:** limpar filtros, resetar busca, navegar, exportar ou criar uma operação.
- **Loading:** spinner substitui/rotaciona o ícone enquanto a consulta estiver em andamento; bloqueio temporário para evitar requisições concorrentes redundantes. **Não aplicar rotação contínua quando inativo.**
- **Acessibilidade:** `aria-label="Atualizar operações"`, `title="Atualizar"`, estado `aria-busy`/equivalente quando apropriado.
- **[VALIDAR]** Se os cards/resumos da tela também forem atualizados atualmente por esse comando, manter a regra existente; se não, atualizar apenas a lista.

### F04 — Botão `Novo`

- **[REFERÊNCIA]** Último elemento da primeira linha, à direita; destaque visual máximo; fundo claro, texto escuro; ícone `+` seguido de `Novo`.
- **Ação:** abrir a mesma tela, modal, fluxo ou rota existente para criação de operação.
- **Permissões:** preservar autorização; ocultar ou desabilitar coerentemente com a lógica atual.
- **Estados:** hover, foco e pressed; evitar múltiplas aberturas; tooltip opcional.
- **Acessibilidade:** nome `Nova operação` se fizer sentido na semântica da aplicação, mantendo `Novo` no texto visível.

### F05 — `Período de criação`

- **[REFERÊNCIA]** Primeiro filtro da segunda linha; ícone de calendário; rótulo **`Período de criação`**; chevron no lado direito.
- **Controle:** gatilho de date-range picker/popover do projeto (não um select de textos estáticos). Permitir escolher data inicial/final conforme fluxo atual.
- **Ao aplicar:** atualizar filtros e voltar à primeira página da tabela. Exibir o período selecionado em forma concisa se couber; caso contrário, manter rótulo `Período de criação` e indicar seleção por estado visual/tooltip.
- **Validação:** data inicial não pode ser posterior à final; observar fusos, inclusividade do último dia e a semântica de 'criação' já usada na API.
- **[VALIDAR]** período padrão atual; se a data é local, UTC ou baseada em `createdAt`; existência de presets e botão aplicar.
- **Acessibilidade:** calendário utilizável por teclado; retornar foco ao botão ao fechar; rótulos de data compreensíveis.

### F06 — `Todos os tipos`

- **[REFERÊNCIA]** Segundo filtro da segunda linha; rótulo **`Todos os tipos`**, chevron à direita.
- **Controle:** dropdown/select com os **tipos reais** de operação do sistema.
- **Estado sem seleção:** `Todos os tipos`.
- **Ao selecionar:** atualizar consulta e voltar à primeira página; mostrar o tipo escolhido no botão.
- **[VALIDAR]** se a seleção atual é única ou múltipla. **Não mudar para multiselect sem necessidade.** Caso seja múltipla, mostrar uma síntese como `2 tipos` sem perder clareza.
- **Acessibilidade:** disparador com `aria-expanded`, rótulo e seleção identificável para leitores de tela; setas, Enter, Espaço e Escape conforme o componente usado.

### F07 — `Situação`

- **[REFERÊNCIA]** Terceiro filtro; rótulo **`Situação`** e chevron.
- **Controle:** dropdown dos status/situações efetivamente definidos no domínio.
- **Estado sem seleção:** `Situação`.
- **Ao selecionar:** reconsultar e voltar à primeira página; exibir nome atual ou resumo se longo.
- **[VALIDAR]** relação entre `Situação` do filtro e `Status` na tabela. **Não deduzir valores ou criar enum novo com base na imagem.**
- **Acessibilidade:** mesmas regras do filtro de tipo.

### F08 — `Mesa`

- **[REFERÊNCIA]** Quarto filtro; rótulo **`Mesa`** e chevron; controle mais curto da linha.
- **Controle:** dropdown com as mesas autorizadas/disponíveis para o usuário.
- **Estado sem seleção:** `Mesa`.
- **Ao selecionar:** atualizar resultado e retornar à primeira página.
- **[RECOMENDAÇÃO]** largura elástica limitada (`min-width` adequada e `max-width`) se houver nomes longos. Não deixar o valor extrapolar o botão.
- **[VALIDAR]** valores, permissões, fallback e nome da propriedade no contrato existente.

### F09 — `× Limpar filtros`

- **[REFERÊNCIA]** Último item da segunda linha; à direita; ícone `×` pequeno seguido de **`Limpar filtros`**; aparência de ação textual, sem borda.
- **Ação:** remover todos os filtros aplicados **e a pesquisa**, retornando aos defaults do sistema; voltar à primeira página; não alterar ordenação se a UI atual não a tratar como filtro.
- **[VALIDAR]** se o período padrão do produto é vazio ou um intervalo predefinido. `Limpar` deve restaurar **esse default**, e não necessariamente ausência absoluta de datas.
- **Estado desabilitado:** quando todos os controles já estiverem nos defaults (incluindo pesquisa); manter texto visível, com contraste reduzido.
- **Não deve:** recarregar dados ignorando filtros em segredo, apagar registros ou executar o mesmo comportamento que `Atualizar`.
- **Acessibilidade:** botão real, nunca apenas `span` clicável; nome claro e foco visível.

## 7. Estado e sincronização

**[RECOMENDAÇÃO]** Modelo lógico único para os filtros, mapeado à arquitetura existente:

```text
ToolbarState
  searchText: string
  createdFrom: date | null
  createdTo: date | null
  selectedTypes: collection | single | null   // preservar cardinalidade atual
  selectedSituation: collection | single | null
  selectedDesk: collection | single | null
  isRefreshing: boolean
  isExporting: boolean
  isLoadingResults: boolean

TableState
  page: number
  pageSize: number
  sortField: string | null
  sortDirection: asc | desc | null
```

### Regras gerais

1. Toda alteração efetiva de busca/filtro deve sincronizar a fonte de dados **sem descartar outros filtros**.
2. Alterar qualquer filtro ou termo de pesquisa coloca `page` na primeira página; **refresh não altera** a página atual.
3. A tabela, paginação e contadores devem refletir a **mesma consulta**; preservar a política de totais existente.
4. Em respostas fora de ordem, prevalece a requisição mais recente (`AbortController`, cancelamento da tarefa ou identificador monotônico, conforme a stack).
5. Estado temporário de popover em edição não deve causar requisições desnecessárias antes de aplicar, quando o componente exigir confirmação.
6. Se já houver sincronização com URL, storage, router ou estado global, preservar a integração e parâmetros atuais.
7. Evitar implementações que duplicam dados, fazem múltiplos fetches acidentais ou vazam listeners.

## 8. Comportamento de tela e responsividade

### 8.1 Desktop amplo — `>= 1024px` [RECOMENDAÇÃO]

- Duas linhas como referência.
- Busca flexível à esquerda; `CSV → Atualizar → Novo` em grupo estável à direita.
- Filtros alinhados à esquerda na segunda linha; `Limpar filtros` no extremo direito.
- Botões e filtros sem quebra de texto; a busca absorve variações de largura primeiro.

### 8.2 Tablet / janela intermediária — `768px a 1023px`

- Manter as duas linhas sempre que possível.
- Diminuir apenas espaços internos excessivos, **não** reduzir tipografia abaixo da escala do design system.
- Permitir que a segunda linha quebre em uma terceira faixa (`flex-wrap`) se necessário, com `row-gap:8px`. Manter `Limpar filtros` no final da última faixa.
- Não permitir scroll horizontal da **página** causado pela toolbar.

### 8.3 Mobile / janelas estreitas — `< 768px`

- Linha de busca usa toda a largura.
- Grupo de ações vai para a linha seguinte sem omitir o botão refresh. `Novo` permanece identificado por texto.
- Filtros quebram em múltiplas linhas ou ocupam largura completa/duas colunas, conforme espaço e componentes existentes.
- Popovers devem caber no viewport ou migrar para painel/modal móvel conforme padrão do projeto.
- Garantir área de toque de pelo menos ~`40–44px` em interfaces de toque, mesmo se a altura visual compacta do desktop for `32–36px`.

### 8.4 Layout de referência e implementação flexível

```css
/* Pseudocódigo CSS de layout: adaptar às classes e tokens do app */
.cambio-toolbar { width: 100%; border: 1px solid var(--toolbar-border); border-radius: 13px; }
.cambio-toolbar__top { display: flex; align-items: center; gap: 8px; }
.cambio-toolbar__search { flex: 1 1 240px; min-width: 0; }
.cambio-toolbar__actions { display: flex; align-items: center; gap: 8px; flex: 0 0 auto; }
.cambio-toolbar__divider { height: 1px; width: 100%; background: var(--toolbar-divider); }
.cambio-toolbar__bottom { display: flex; align-items: center; flex-wrap: wrap; gap: 8px; }
.cambio-toolbar__clear { margin-left: auto; }
@media (max-width: 767px) {
  .cambio-toolbar__top { flex-wrap: wrap; }
  .cambio-toolbar__search { flex-basis: 100%; }
  .cambio-toolbar__actions { margin-left: auto; }
}
```

**Não usar `position:absolute` para alinhar CSV, refresh, Novo ou Limpar.** A toolbar precisa suportar zoom de 200%, nomes de opções mais longos e diferentes traduções sem sobreposição.

## 9. Requisitos de componentes e acessibilidade

- Usar componentes existentes (`Button`, `Input`, `Select`, `DateRangePicker`, `Tooltip`, etc.) antes de criar novos.
- Ícones recomendados: `Search`, `Download`, `RefreshCw`, `Plus`, `CalendarDays`, `ChevronDown`, `X`. Usar nomes equivalentes da biblioteca instalada, sem adicionar dependência só por estética.
- `button` nativo para comandos; `input` nativo/controle acessível para busca; selects/popovers com papéis ARIA corretos.
- Ordem de Tab: **Busca → CSV → Atualizar → Novo → Período → Tipo → Situação → Mesa → Limpar filtros**.
- `Esc` fecha um popover aberto; foco retorna ao disparador; `Enter`/Espaço operam conforme componente.
- Ícone isolado de refresh recebe `aria-label` e tooltip (não depender só de hover para descobrir sua função).
- Loading e resultado vazio precisam de feedback legível; usar região `aria-live` com moderação para alterações relevantes.
- Preservar o contraste e os estilos de `:focus-visible` do aplicativo.

## 10. Casos de UI que precisam ser testados

| Cenário | Resultado esperado |
|---|---|
| Página sem filtros | Placeholders como na referência; `Limpar filtros` desabilitado |
| Busca preenchida | texto no campo; consulta filtrada; limpar habilitado |
| Busca + 2 filtros | todos os critérios combinados, sem sobrescrever uns aos outros |
| Período definido | datas mantidas após refresh; validação de limites |
| Tipo/situação/mesa longos | controle continua alinhado; texto truncado com tooltip se indispensável |
| Refresh acionado | consulta repetida, spinner, **sem reset** de filtros ou página |
| Limpar acionado | restaura defaults de filtros e pesquisa, retorna à primeira página |
| Exportar CSV | preserva comportamento e permissão da exportação existente |
| Novo acionado | abre fluxo existente de cadastro/criação |
| Usuário sem permissão de criar/exportar | respeita as permissões já implementadas |
| API lenta ou com erro | não duplica requisições; mostra feedback; filtros permanecem |
| Resultado sem registros | mostra empty state coerente com o produto |
| Viewport 729px | componente semelhante à referência, sem controles sobrepostos |
| Viewport 375px | layout empilhado, todos os comandos disponíveis |
| Zoom 200% e teclado | navegação possível, foco visível, sem conteúdo cortado |

## 11. Restrições: o que NÃO modificar

- Não alterar a estrutura/colunas da tabela, sua ordenação ou paginação por efeito colateral.
- Não redesenhar as informações e limites de tesouraria.
- Não trocar o design system inteiro nem impor fonte/cores globais.
- Não incluir novos filtros como Moeda, Urgência ou Canal **nesta Opção 1** (essas eram alternativas exploratórias, não a opção aprovada na imagem).
- Não transformar tudo em um botão genérico `Filtros` nesta opção.
- Não suprimir `CSV`, `Atualizar` ou `Novo` para economizar espaço.
- Não renomear a ação visual `CSV` para `Exportar CSV` sem autorização; `Exportar CSV` fica no tooltip/label acessível.
- Não substituir uma integração real por dados mockados nem introduzir chamadas de API imaginárias.

## 12. Plano de implementação sugerido

1. Localizar o componente atual da tela Câmbio e identificar toolbar, filtros, busca, handlers, permissões, exportação e refresh.
2. Mapear onde ficam os estados atuais e contratos da listagem, sem reimplementar regras de domínio.
3. Refatorar **somente a árvore de layout** da toolbar para duas faixas com divisor.
4. Reutilizar controles atuais e ajustar dimensões, ícones, rótulos e classes locais.
5. Verificar debounce da busca e sincronização dos filtros, sem múltiplas consultas redundantes.
6. Garantir a posição/funcionamento do **Refresh entre CSV e Novo**.
7. Criar estilos responsivos locais e estados hover/focus/loading/disabled.
8. Validar manualmente com a imagem de referência lado a lado.
9. Executar testes disponíveis e corrigir regressões.
10. Entregar resumo de arquivos alterados, decisões tomadas, pontos não verificáveis e capturas da toolbar pronta em desktop/mobile.

## 13. Critérios de aceite (Definition of Done)

- [ ] Toolbar visualmente fiel à imagem escura fornecida.
- [ ] Contêiner arredondado e divisor horizontal presentes.
- [ ] Primeira linha: pesquisa à esquerda + `CSV`, `Atualizar`, `Novo` à direita, **nessa ordem**.
- [ ] Segunda linha: `Período de criação`, `Todos os tipos`, `Situação`, `Mesa` à esquerda; `× Limpar filtros` à direita.
- [ ] Busca com largura flexível e ações alinhadas, sem grandes espaços artificiais.
- [ ] Campo de pesquisa e os quatro filtros continuam funcionais usando lógica real do projeto.
- [ ] `Atualizar` preserva estado dos filtros; `Limpar filtros` restaura defaults e são funções distintas.
- [ ] Exportação e criação continuam operando através dos fluxos já existentes.
- [ ] Funciona em largura pequena e zoom, sem clipping e sem scroll horizontal indevido.
- [ ] Keyboard, rótulos acessíveis, foco, hover, loading e erro tratados.
- [ ] Não há alteração indevida nos cards, tabela ou backend.
- [ ] Código segue convenções do repositório e passa nos testes/build relevantes.

## 14. Mensagem pronta para o agente implementador

> Analise o código atual da tela **Câmbio** e implemente **exclusivamente** a toolbar de pesquisa, filtros e ações, conforme `OPCAO_1_EQUILIBRADA_HANDOFF.md` e a imagem `referencia-opcao-1-equilibrada.png`. Preserve o tema escuro, o design system, handlers, contratos e permissões existentes. A primeira linha terá Busca / CSV / Atualizar / Novo, e a segunda Período de criação / Todos os tipos / Situação / Mesa / Limpar filtros. **Refresh é obrigatório, fica entre CSV e Novo e não limpa filtros.** Não criar endpoints nem opções de filtros fictícios. Faça o layout responsivo, estados de interação e verificações de acessibilidade; rode os testes/build pertinentes. No final, descreva o que mudou e quaisquer decisões que precisaram de validação.

---

### Observação sobre fidelidade

Esta documentação descreve a **toolbar de 729 × 165 px anexada nesta conversa**, e não os mockups anteriores com tema claro. O arquivo de imagem deve acompanhar o Markdown ao ser passado para outro agente. Valores de pixel e cores são recomendações de implementação, não uma captura de especificações internas do sistema.
